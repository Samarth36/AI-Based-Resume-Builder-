<?php
session_start();
$url = (isset($_POST['url']) && $_POST['url'])?$_POST['url']:'';
 //$actual_link = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    $_SESSION['actual_link']=$url;
?>


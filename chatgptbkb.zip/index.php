<!DOCTYPE html>
<html class="no-js">
<head>
	<meta charset="UTF-8">
	 <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" >

	<title>p2p Auto</title>
<link rel="shortcut icon" href="favicon.ico">        
	<link href="favicon.ico" rel="icon" type="image/x-icon" />
 <!-- Custom styles for this template -->
     <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/cover.css" rel="stylesheet">
	<!--<link href="<?php echo DOMAIN; ?>css/font-awesome.min.css" rel="stylesheet">-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<script src="js/jquery-1.8.0.min.js" type="text/javascript"></script>
	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
<script src="ChatGPT.js?v=14"></script>

</head>


<body data-spy="scroll"  onload="OnLoad()" style="background:#EFEFEF;">

<div class="cover-container d-flex h-100 p-3 mx-auto flex-column col-md-6">
      <!--<header class="masthead mb-auto">
        <div class="inner" style="text-align: center;">
          <h3 class="masthead-brand">Cover</h3>
          
        </div>
      </header>-->

      <main role="main" class="inner cover" style="text-align: center;">
          <div style='height:20px;'></div>
         


       
           
        <h1 class="cover-heading">My ChatGPT ORG</h1>
        
        <p class="lead" style="font-size: 0.8rem;">PLease enter text </p>
        <p class="lead">
         
          <div id="idContainer">
            
            <div>
                <div class="search searchbar"> <input type="text" id="txtMsg" class="search_input " placeholder="Enter your question here..." name=""> <a href="#" class="search-icon"  onclick="Send()"  id="btnSend"> <i class="fa fa-search"></i> </a> </div>
              
                <div id="idText"></div>
               
                <input type="hidden" id="selModel" value="text-davinci-003">   
                <input type="hidden" id="selLang" value="en-US">   
               
            </div>
           
           <textarea id="txtOutput" rows="6" style="margin-top: 10px; width: 100%;background-color: unset;border: 1px solid #ccc;" ></textarea>
           
          </div>
        </p>
        
      
        <button type="button" class="btn btn-secondary"  onclick="document.getElementById('txtOutput').value = '';">Clear</button>
        
       
      </main>

      
    </div>
    
 

<style>

    .searchbar {
  margin-bottom: auto;
  margin-top: auto;
 background-color: #353b48;
  border-radius: 30px;
  padding: 10px;
}
.search_input {
  color: white;
  border: 0;
  outline: 0;
  background: none;
  width: 90%;
  /*caret-color: transparent;*/
  line-height: 40px;
  transition: width 0.4s linear;
}
</style>
 <script src="https://code.jquery.com/jquery-3.1.1.min.js">
    <script>window.jQuery || document.write('<script src="js/jquery-slim.min.js"><\/script>')</script>
    <script src="js/popper.min.js"></script>    
    <script src="js/bootstrap.min.js"></script>
    
    
<script type="text/javascript">



function goto(gotourl)
{
	window.location.href=gotourl;
}
</script>


<!-- start subscribe news letter -->
<script type="text/javascript">
document.getElementById('txtMsg').onkeydown = function(e){
   if(e.keyCode == 13){
     Send();
   }
};






    


function unloadJS(scriptName) {
  var head = document.getElementsByTagName('head').item(0);
  var js = document.getElementById(scriptName);
  js.parentNode.removeChild(js);
}


//----------------------
function unloadAllJS() {
  var jsArray = new Array();
  jsArray = document.getElementsByTagName('script');
  for (i = 0; i < jsArray.length; i++){
    if (jsArray[i].id){
      unloadJS(jsArray[i].id)
    }else{
      jsArray[i].parentNode.removeChild(jsArray[i]);
    }
  }      
}
  </script>
  
  <style>
  .cover-heading{ margin-top:10px;margin-bottom: 0px; }
      ul {
  list-style: none;
  margin: 0px;
  padding: 0px;
}

.social-icons22 li {

    float: left;
    margin: 3px;
border-radius: 0 !important;
}
 a, li {
  color: #fff;
  line-height: 1.6;
}
.footerclas{
    font-size: 12px;
padding: 11px 0 7px;

/*border-top: solid 1px #777;*/
}

      
  </style>
 <script>
    $(document).ready(function() {
    document.onkeydown = function(e){
        if (e.ctrlKey &&
            (e.keyCode === 67 ||
                e.keyCode === 86 ||
                e.keyCode === 85 ||
                e.keyCode === 117)) {
            return false;
        } else {
            return true;
        }
    };
});
document.addEventListener('contextmenu', 
     event => event.preventDefault()
);
 </script>
  </body>
</html>